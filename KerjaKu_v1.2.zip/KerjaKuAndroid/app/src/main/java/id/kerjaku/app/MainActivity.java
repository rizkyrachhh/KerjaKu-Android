package id.kerjaku.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;
import android.util.Base64;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int PICK_BACKUP_FOLDER = 7412;
    private static final int PICK_IMPORT_FILE = 7413;
    private WebView webView;
    private String pendingFilename, pendingData;
    private Uri backupDirUri;

    private class KerjaKuBridge {
        @JavascriptInterface
        public String saveBase64(String filename, String data) {
            String safeName = filename == null ? "KerjaKu_Backup.json" : filename.replaceAll("[^A-Za-z0-9._-]", "_");
            if (!safeName.toLowerCase().endsWith(".json") && !safeName.toLowerCase().endsWith(".csv")) return "ERROR: format file tidak didukung";
            Uri dir = getBackupDirectory();
            if (dir == null) {
                pendingFilename = safeName;
                pendingData = data;
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "Pilih folder Android/media. KerjaKu akan membuat folder KerjaKu.app.", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(intent, PICK_BACKUP_FOLDER);
                });
                return "PICKER_REQUIRED";
            }
            return writeFile(dir, safeName, data);
        }

        @JavascriptInterface
        public void pickImport() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(intent, PICK_IMPORT_FILE);
            });
        }

        @JavascriptInterface
        public String backupFolder() {
            Uri dir = getBackupDirectory();
            return dir == null ? "Pilih folder saat melakukan backup pertama kali" : "Penyimpanan internal/Android/media/KerjaKu.app";
        }
    }

    private Uri getBackupDirectory() {
        if (backupDirUri != null) return backupDirUri;
        String saved = getPreferences(MODE_PRIVATE).getString("backup_tree_uri", null);
        if (saved == null) return null;
        try { backupDirUri = Uri.parse(saved); return backupDirUri; } catch (Exception e) { return null; }
    }

    private Uri findOrCreateFolder(Uri parent, String name) throws Exception {
        String id = DocumentsContract.getTreeDocumentId(parent);
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(parent, id);
        try (android.database.Cursor c = getContentResolver().query(children, new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE}, null, null, null)) {
            if (c != null) while (c.moveToNext()) {
                if (name.equals(c.getString(1)) && DocumentsContract.Document.MIME_TYPE_DIR.equals(c.getString(2)))
                    return DocumentsContract.buildDocumentUriUsingTree(parent, c.getString(0));
            }
        }
        return DocumentsContract.createDocument(getContentResolver(), DocumentsContract.buildDocumentUriUsingTree(parent, id), DocumentsContract.Document.MIME_TYPE_DIR, name);
    }

    private Uri createBackupPath(Uri pickedTree) throws Exception {
        Uri appFolder = findOrCreateFolder(pickedTree, "KerjaKu.app");
        return appFolder;
    }

    private String writeFile(Uri directory, String filename, String data) {
        try {
            Uri fileUri = DocumentsContract.createDocument(getContentResolver(), directory,
                    filename.toLowerCase().endsWith(".csv") ? "text/csv" : "application/json", filename);
            if (fileUri == null) return "ERROR: file tidak dapat dibuat";
            byte[] bytes = Base64.decode(data, Base64.DEFAULT);
            try (OutputStream out = getContentResolver().openOutputStream(fileUri, "w")) { if (out == null) return "ERROR: penyimpanan tidak tersedia"; out.write(bytes); out.flush(); }
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Backup tersimpan di KerjaKu.app: " + filename, Toast.LENGTH_LONG).show());
            return "OK: " + filename;
        } catch (Exception e) { return "ERROR: " + e.getMessage(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent resultData) {
        super.onActivityResult(requestCode, resultCode, resultData);
        if (requestCode == PICK_IMPORT_FILE) {
            if (resultCode == RESULT_OK && resultData != null && resultData.getData() != null) {
                Uri fileUri = resultData.getData();
                try (java.io.InputStream in = getContentResolver().openInputStream(fileUri);
                     java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream()) {
                    if (in == null) throw new Exception("File tidak dapat dibuka");
                    byte[] chunk = new byte[8192]; int n;
                    while ((n = in.read(chunk)) != -1) buffer.write(chunk, 0, n);
                    String encoded = Base64.encodeToString(buffer.toByteArray(), Base64.NO_WRAP);
                    webView.evaluateJavascript("window.handleNativeImportBase64('" + encoded + "')", null);
                } catch (Exception e) {
                    Toast.makeText(this, "Gagal membaca backup: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        } else if (requestCode == PICK_BACKUP_FOLDER) {
            if (resultCode == RESULT_OK && resultData != null && resultData.getData() != null) {
                Uri tree = resultData.getData();
                try {
                    getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    backupDirUri = createBackupPath(tree);
                    getPreferences(MODE_PRIVATE).edit().putString("backup_tree_uri", backupDirUri.toString()).apply();
                    if (pendingFilename != null && pendingData != null) writeFile(backupDirUri, pendingFilename, pendingData);
                } catch (Exception e) { Toast.makeText(this, "Gagal menyiapkan folder: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
            } else Toast.makeText(this, "Pemilihan folder dibatalkan. Backup belum disimpan.", Toast.LENGTH_LONG).show();
            pendingFilename = null; pendingData = null;
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFFF4F6FB);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true); settings.setAllowContentAccess(false); settings.setLoadsImagesAutomatically(true); settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.addJavascriptInterface(new KerjaKuBridge(), "KerjaKuNative");
        webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView); webView.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
